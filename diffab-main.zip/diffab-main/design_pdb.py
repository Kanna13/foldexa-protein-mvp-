from diffab.tools.runner.design_for_pdb import args_from_cmdline, design_for_pdb

if __name__ == '__main__':
    design_for_pdb(args_from_cmdline())
