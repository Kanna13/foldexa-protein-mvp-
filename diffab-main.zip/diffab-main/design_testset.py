from diffab.tools.runner.design_for_testset import main

if __name__ == '__main__':
    main()
