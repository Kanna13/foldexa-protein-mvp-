# self test suite
These tests are design to help debug interface between testing server and Rosetta testing scripts

-----
### python
Test Python platform support and functionality of local and persistent Python virtual environments
